#ifndef MAIN_H_
#define MAIN_H_

#include "stm32f4xx_hal.h"
#include "lcd.h"
#include "ili9341.h"

#endif /* MAIN_H_ */
